import path from "node:path";
import dns from "node:dns";
import { config } from "../../config/index.js";
import { ResumeVectorStore } from "../../lib/vectorstore/index.js";
import { loadDocument, getResumeFiles, LLMMetadataExtractor } from "../../utils/index.js";
import type { ResumeData } from "../../types/index.js";

// Fix DNS resolution issue on macOS and local networks
// Uses Google's public DNS servers for reliable MongoDB Atlas SRV record resolution
dns.setServers(['8.8.8.8', '8.8.4.4']);

/**
 * Main ingestion pipeline with LLM-based metadata extraction and vector embeddings using Mistral
 * Flow: Load -> LLM metadata extraction -> Mistral embeddings -> MongoDB vector store -> Next (no delays)
 */
export async function ingestResumes(clearExisting: boolean = false): Promise<void> {
  console.log("🚀 Starting resume ingestion pipeline with LLM metadata extraction and vector embeddings\n");
  
  // Validate configuration
  if (!config.mongodb.uri) {
    throw new Error("MONGODB_URI is not set in .env file");
  }
  
  const embeddingProvider = config.embeddings.provider;
  const embeddingApiKey = config.mistral.apiKey;
  
  if (!embeddingApiKey) {
    throw new Error("MISTRAL_API_KEY is required for generating embeddings");
  }

  // Initialize LLM metadata extractor with no delay (process immediately)
  const llmExtractor = new LLMMetadataExtractor(
    config.groq.apiKey,
    config.groq.model,
    0 // No minimum delay - process immediately
  );
  
  console.log(`📊 Configuration:`);
  console.log(`  - Database: ${config.mongodb.dbName}.${config.mongodb.collection}`);
  console.log(`  - Embedding Provider: ${embeddingProvider}`);
  console.log(`  - Embedding Model: ${config.embeddings.model}`);
  console.log(`  - Embedding Dimension: ${config.embeddings.dimension}`);
  console.log(`  - LLM Provider: Groq`);
  console.log(`  - LLM Model: ${config.groq.model}`);
  console.log(`  - LLM Min Delay: 2000ms`);
  console.log();
  
  // Initialize LangChain MongoDB Vector Store
  const vectorStore = new ResumeVectorStore({
    mongoUri: config.mongodb.uri,
    dbName: config.mongodb.dbName,
    collectionName: config.mongodb.collection,
    indexName: config.mongodb.vectorIndexName,
    embeddingProvider: embeddingProvider,
    embeddingModel: config.embeddings.model,
    apiKey: embeddingApiKey
  });
  
  try {
    // Connect to MongoDB
    await vectorStore.initialize();
    
    // Clear existing data if requested
    if (clearExisting) {
      console.log("🗑️  Clearing existing resumes...");
      await vectorStore.clearCollection();
      console.log();
    }
    
    // Get all resume files
    console.log(`📂 Reading documents from: ${config.documents.folder}`);
    const resumeFiles = await getResumeFiles(config.documents.folder);
    
    if (resumeFiles.length === 0) {
      console.log("⚠️  No PDF or DOCX files found in documents folder");
      return;
    }
    
    console.log(`✓ Found ${resumeFiles.length} resume(s)\n`);
    
    // Process each resume with LLM metadata extraction directly
    console.log("📝 Processing resumes with LLM metadata extraction...\n");
    const resumesData: ResumeData[] = [];
    
    let successCount = 0;
    let errorCount = 0;
    let skippedCount = 0;
    const warnings: Array<{ fileName: string; warnings: string[] }> = [];
    
    // Process resumes sequentially with LLM extraction
    for (const filePath of resumeFiles) {
      const fileName = path.basename(filePath);
      
      console.log(`  📄 Processing: ${fileName}...`);
      const startTime = Date.now();
      
      try {
        // Load document content
        const content = await loadDocument(filePath);
        
        if (!content || content.trim().length === 0) {
          console.log(`    ❌ SKIPPED: Empty file\n`);
          skippedCount++;
          errorCount++;
          continue;
        }
        
        // Use LLM to extract ALL metadata directly (no regex extraction)
        console.log(`    🤖 Extracting metadata with LLM...`);
        const llmMetadata = await llmExtractor.extractMetadata(content, "unknown@example.com");
        
        // Check if we got essential data from LLM
        if (!llmMetadata.name && !llmMetadata.currentTitle) {
          console.log(`    ❌ SKIPPED: LLM could not extract key information\n`);
          skippedCount++;
          continue;
        }
        
        // Create resume data object with LLM extracted information
        const resumeData: ResumeData = {
          email: llmMetadata.name ? `${llmMetadata.name.replace(/\s+/g, '.').toLowerCase()}@generated.local` : "unknown@example.local",
          phoneNumber: "Not extracted",
          fullContent: content,
          fileName: fileName,
          processedAt: new Date(),
          ...llmMetadata // Spread LLM extracted metadata
        };
        
        console.log(`    ✓ Name: ${llmMetadata.name || "N/A"}`);
        
        if (llmMetadata.currentTitle) {
          console.log(`    ✓ Current Title: ${llmMetadata.currentTitle}`);
        }
        if (llmMetadata.currentOrganisation) {
          console.log(`    ✓ Organization: ${llmMetadata.currentOrganisation}`);
        }
        if (llmMetadata.yearsOfExperience) {
          console.log(`    ✓ Experience: ${llmMetadata.yearsOfExperience} years`);
        }
        if (llmMetadata.skills && llmMetadata.skills.length > 0) {
          console.log(`    ✓ Skills: ${llmMetadata.skills.slice(0, 3).join(", ")}${llmMetadata.skills.length > 3 ? `... (+${llmMetadata.skills.length - 3} more)` : ""}`);
        }
        if (llmMetadata.locations && llmMetadata.locations.length > 0) {
          console.log(`    ✓ Locations: ${llmMetadata.locations.join(", ")}`);
        }
        if (llmMetadata.educationLevel) {
          console.log(`    ✓ Education: ${llmMetadata.educationLevel}`);
        }
        
        const processingTime = Date.now() - startTime;
        console.log(`    ⏱️  Time: ${processingTime}ms`);
        
        // Immediately embed and push to database (no waiting)
        console.log(`    🔄 Embedding and storing...`);
        await vectorStore.addResumesBatch([resumeData], 1);
        console.log(`    ✅ Stored to database\n`);
        
        successCount++;
        
      } catch (error) {
        console.error(`    ❌ Error:`, error instanceof Error ? error.message : String(error));
        console.log();
        errorCount++;
      }
    }
    
    // Summary
    console.log("\n" + "=".repeat(70));
    console.log("✅ INGESTION COMPLETE");
    console.log("=".repeat(70));
    console.log(`📊 Statistics:`);
    console.log(`  - Total files: ${resumeFiles.length}`);
    console.log(`  - Successful: ${successCount}`);
    console.log(`  - Skipped: ${skippedCount}`);
    console.log(`  - Errors: ${errorCount}`);
    console.log(`  - Total processed: ${successCount + skippedCount + errorCount}`);
    console.log();

  } catch (error) {
    console.error("❌ Ingestion failed:", error instanceof Error ? error.message : String(error));
    throw error;
  } finally {
    // Close MongoDB connection
    await vectorStore.close();
  }
}

/**
 * Run the ingestion pipeline if this script is executed directly
 * Usage: tsx src/pipelines/ingestion/pipeline.ts [--clear]
 */
async function main() {
  const clearExisting = process.argv.includes("--clear");
  
  try {
    await ingestResumes(clearExisting);
    console.log("Done!");
    process.exit(0);
  } catch (error) {
    console.error("Fatal error:", error);
    process.exit(1);
  }
}

// Run if executed directly
if (process.argv[1]?.includes("pipeline")) {
  main();
}
