import { ChatGroq } from "@langchain/groq";
import { LLMExtractedMetadata } from "../types/resume.js";

/**
 * LLM-based metadata extractor using Groq
 * Extracts structured metadata from resume content with minimal delay
 */
export class LLMMetadataExtractor {
  private llm: ChatGroq;
  private delayMs: number;

  constructor(apiKey: string, model: string, delayMs: number = 2000) {
    this.llm = new ChatGroq({
      apiKey,
      model,
      temperature: 0.2,
      maxTokens: 1024,
    });
    this.delayMs = delayMs;
  }

  /**
   * Extract metadata from resume content using Groq LLM
   * Returns best matching values for each metadata field
   */
  async extractMetadata(resumeContent: string, email: string): Promise<LLMExtractedMetadata> {
    try {
      const prompt = this.buildExtractionPrompt(resumeContent, email);
      
      // Call Groq LLM
      const startTime = Date.now();
      const response = await this.llm.invoke(prompt);
      const elapsedTime = Date.now() - startTime;
      
      // Apply minimal delay if elapsed time is less than configured delay
      const remainingDelay = Math.max(0, this.delayMs - elapsedTime);
      if (remainingDelay > 0) {
        await new Promise(resolve => setTimeout(resolve, remainingDelay));
      }
      
      // Parse the response
      const metadata = this.parseMetadataResponse(response.content as string);
      return metadata;
    } catch (error) {
      console.error("Error extracting metadata with LLM:", error);
      // Return empty metadata on error, pipeline will continue
      return {};
    }
  }

  /**
   * Build the extraction prompt for Groq
   */
  private buildExtractionPrompt(resumeContent: string, email: string): string {
    return `You are an expert resume parser. Extract structured metadata from the provided resume.

Resume Content:
---
${resumeContent.substring(0, 4000)}
---

Email: ${email}

Extract and return ONLY a valid JSON object (no markdown, no code blocks) with the following fields:
{
  "name": "Full name of the candidate",
  "locations": ["list of cities/countries where candidate has worked or willing to work"],
  "skills": ["list of key skills"],
  "technologies": ["list of programming languages, tools, frameworks, databases"],
  "currentOrganisation": "Current employer name",
  "currentTitle": "Current job title",
  "yearsOfExperience": number of years in current role,
  "totalExperience": "Total years of experience",
  "educationLevel": "Highest education level (e.g., Bachelor's, Master's, PhD)",
  "certifications": ["list of certifications"],
  "languages": ["list of languages spoken"],
  "previousOrganisations": ["list of previous employers"],
  "previousTitles": ["list of previous job titles"]
}

Rules:
- Only include fields that are clearly mentioned or can be inferred from the resume
- For arrays, return empty array [] if not found
- For strings, return empty string "" if not found
- For numbers, return 0 if not found
- Return valid JSON only, no additional text
- Be concise and accurate

Valid JSON Response:`;
  }

  /**
   * Parse the LLM response to extract metadata
   */
  private parseMetadataResponse(response: string): LLMExtractedMetadata {
    try {
      // Extract JSON from response (handle cases where LLM adds extra text)
      const jsonMatch = response.match(/\{[\s\S]*\}/);
      if (!jsonMatch) {
        console.warn("No JSON found in LLM response");
        return {};
      }

      const parsed = JSON.parse(jsonMatch[0]) as LLMExtractedMetadata;
      
      // Validate and sanitize the extracted data
      return this.sanitizeMetadata(parsed);
    } catch (error) {
      console.error("Error parsing LLM response:", error);
      return {};
    }
  }

  /**
   * Sanitize and validate extracted metadata
   */
  private sanitizeMetadata(metadata: any): LLMExtractedMetadata {
    const sanitized: LLMExtractedMetadata = {};

    // Name
    if (metadata.name && typeof metadata.name === "string" && metadata.name.trim()) {
      sanitized.name = metadata.name.trim();
    }

    // Locations array
    if (Array.isArray(metadata.locations)) {
      const locations = metadata.locations
        .filter((l: any) => typeof l === "string" && l.trim())
        .map((l: any) => l.trim());
      if (locations.length > 0) {
        sanitized.locations = locations;
      }
    }

    // Skills array
    if (Array.isArray(metadata.skills)) {
      const skills = metadata.skills
        .filter((s: any) => typeof s === "string" && s.trim())
        .map((s: any) => s.trim());
      if (skills.length > 0) {
        sanitized.skills = skills;
      }
    }

    // Technologies array
    if (Array.isArray(metadata.technologies)) {
      const technologies = metadata.technologies
        .filter((t: any) => typeof t === "string" && t.trim())
        .map((t: any) => t.trim());
      if (technologies.length > 0) {
        sanitized.technologies = technologies;
      }
    }

    // Current Organisation
    if (metadata.currentOrganisation && typeof metadata.currentOrganisation === "string" && metadata.currentOrganisation.trim()) {
      sanitized.currentOrganisation = metadata.currentOrganisation.trim();
    }

    // Current Title
    if (metadata.currentTitle && typeof metadata.currentTitle === "string" && metadata.currentTitle.trim()) {
      sanitized.currentTitle = metadata.currentTitle.trim();
    }

    // Years of Experience
    if (typeof metadata.yearsOfExperience === "number" && metadata.yearsOfExperience >= 0) {
      sanitized.yearsOfExperience = Math.floor(metadata.yearsOfExperience);
    }

    // Total Experience
    if (metadata.totalExperience && typeof metadata.totalExperience === "string" && metadata.totalExperience.trim()) {
      sanitized.totalExperience = metadata.totalExperience.trim();
    }

    // Education Level
    if (metadata.educationLevel && typeof metadata.educationLevel === "string" && metadata.educationLevel.trim()) {
      sanitized.educationLevel = metadata.educationLevel.trim();
    }

    // Certifications array
    if (Array.isArray(metadata.certifications)) {
      const certifications = metadata.certifications
        .filter((c: any) => typeof c === "string" && c.trim())
        .map((c: any) => c.trim());
      if (certifications.length > 0) {
        sanitized.certifications = certifications;
      }
    }

    // Languages array
    if (Array.isArray(metadata.languages)) {
      const languages = metadata.languages
        .filter((l: any) => typeof l === "string" && l.trim())
        .map((l: any) => l.trim());
      if (languages.length > 0) {
        sanitized.languages = languages;
      }
    }

    // Previous Organisations array
    if (Array.isArray(metadata.previousOrganisations)) {
      const previousOrganisations = metadata.previousOrganisations
        .filter((o: any) => typeof o === "string" && o.trim())
        .map((o: any) => o.trim());
      if (previousOrganisations.length > 0) {
        sanitized.previousOrganisations = previousOrganisations;
      }
    }

    // Previous Titles array
    if (Array.isArray(metadata.previousTitles)) {
      const previousTitles = metadata.previousTitles
        .filter((t: any) => typeof t === "string" && t.trim())
        .map((t: any) => t.trim());
      if (previousTitles.length > 0) {
        sanitized.previousTitles = previousTitles;
      }
    }

    return sanitized;
  }
}
