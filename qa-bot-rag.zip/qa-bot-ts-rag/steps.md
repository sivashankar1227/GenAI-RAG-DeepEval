
Steps to implement

1. Extract the code and add folder to your workspace (existing)
2. npm install
3. update groq and mistral key in .env
4. npm run dev
5. Test the endpoints using postman.

Steps to add 

1. Integrate deepeval to test the output of the endpoints.
   /test/resumes >>> search/resumes >>> test the input (query + docs) and output using deepeval.
2. Start with one metric (answer relevance) and then add more metrics.
3. Build a web app (use rag-mongo-demo) as reference so that HR can use

Note: Use my mongo connection string for testing purpose.