// vector_search_movie.js (plot-based)
import { MongoClient } from "mongodb";
import dns from "dns";
import axios from "axios";
import dotenv from "dotenv";
import fs from "fs";

dotenv.config();
dns.setServers(["8.8.8.8", "8.8.4.4"]);

const {
  MONGODB_URI="mongodb+srv://shan:Leaf%40123@leafeagle.hcbh7a9.mongodb.net/?retryWrites=true&w=majority&appName=LeafEagle",
  DB_NAME = "sample_mflix",
  COLLECTION_NAME = "embedded_movies",
  VECTOR_INDEX_NAME = "vector_movies", // <-- must match Atlas Search index name
  TESTLEAF_API_BASE = "https://api.testleaf.com/ai", // your working base
  USER_EMAIL="sudarshan.ramanujam@qeagle.com",
  AUTH_TOKEN="494NZhc5+GKJ"
} = process.env;

const client = new MongoClient(MONGODB_URI, { serverSelectionTimeoutMS: 15000 });

async function getEmbedding(query) {
  const url = `${TESTLEAF_API_BASE}/embedding/text/${encodeURIComponent(USER_EMAIL)}`;
  const headers = { "Content-Type": "application/json", ...(AUTH_TOKEN && { Authorization: `Bearer ${AUTH_TOKEN}` }) };
  const body = { input: query, model: "text-embedding-3-small" }; // 1536 dims

  const { data } = await axios.post(url, body, { headers });
  if (data?.status !== 200) throw new Error(data?.message || "Embedding API error");
  const vec = data?.data?.[0]?.embedding;
  if (!Array.isArray(vec)) throw new Error("No embedding in response");
  return { vec, usage: { tokens: data?.usage?.total_tokens || 0, cost: data?.cost || 0, model: data?.model } };
}

async function main() {
  const query = process.argv[2] || "Michael  Geste leaves England in disgrace and joins the infamous";
  console.log(`🔎 Query: "${query}"`);

  try {
    const { vec, usage } = await getEmbedding(query);
    await client.connect();
    const col = client.db(DB_NAME).collection(COLLECTION_NAME);

    const pipeline = [
      {
        $vectorSearch: {
          index: VECTOR_INDEX_NAME,
          path: "plot_embedding",       // <-- matches your stored field
          queryVector: vec,
          numCandidates: 400,
          limit: 8
        }
      },
      {
        $project: {
          _id: 0,
          title: 1,
          year: 1,
          imdb_rating: "$imdb.rating",
          plot: { $ifNull: ["$fullplot", "$plot"] },
          score: { $meta: "vectorSearchScore" }
        }
      }
    ];

    const results = await col.aggregate(pipeline).toArray();
    if (!results.length) {
      console.log("⚠️ No results found. Check index name, field path, and vector dimensions.");
    } else {
      console.table(results.map(r => ({
        title: r.title,
        year: r.year,
        imdb_rating: r.imdb_rating,
        score: Number(r.score).toFixed(4)
      })));
    }

    const out = `movies_search_results_${Date.now()}.json`;
    fs.writeFileSync(out, JSON.stringify({ query, usage, results }, null, 2));
    console.log(`📁 Saved: ${out}`);
  } catch (e) {
    console.error("❌", e.message);
  } finally {
    await client.close().catch(() => {});
  }
}

main();
