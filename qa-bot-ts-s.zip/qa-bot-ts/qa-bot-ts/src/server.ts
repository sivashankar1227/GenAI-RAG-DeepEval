import "dotenv/config";
import express from "express";
import multer from "multer";
import os from "node:os";
import path from "node:path";
import fs from "node:fs/promises";
import { createChatModel, getModelInfo } from "./model.js";
import { buildQAChain } from "./chain.js";
import { loadDocumentToString } from "./loaders.js";
import { InvokeSchema, InvokeBody, InvokeResult } from "./types.js";

const app = express();
app.use(express.json({ limit: "10mb" }));

// Serve the Single Page Application static files from /public
app.use(express.static(path.join(process.cwd(), "public")));

// SPA fallback: serve index.html for unknown GET routes (so client-side routing works)
app.get("/", (req, res) => {
  res.sendFile(path.join(process.cwd(), "public", "index.html"));
});

// Multer setup for handling file uploads in multipart/form-data
const upload = multer({ dest: os.tmpdir() });

// Health check endpoint
app.get("/health", (req, res) => {
  const modelInfo = getModelInfo();
  res.json({
    status: "healthy",
    timestamp: new Date().toISOString(),
    model: modelInfo
  });
});

app.post("/search/document", async (req, res) => {
  const requestId = `req_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  
  try {
    console.log(`\n[${requestId}] === NEW REQUEST RECEIVED ===`);
    console.log(`Timestamp: ${new Date().toISOString()}`);
    console.log(`Request Body:`, JSON.stringify(req.body, null, 2));

    // If the request is multipart/form-data, run multer to process any file uploads
    if (req.is && req.is("multipart/form-data")) {
      await new Promise((resolve, reject) => {
        // Accept any file fields so clients can upload multiple files without "Unexpected field"
        upload.any()(req as any, res, (err: any) => {
          if (err) reject(err);
          else resolve(null);
        });
      });

      // If files were uploaded, set documentPath temporarily (first file) so the schema refinement passes.
      const uploadedFilesTemp = (req as any).files as any[] | undefined;
      if (uploadedFilesTemp && uploadedFilesTemp.length > 0) {
        const first = uploadedFilesTemp[0];
        const uploadedPathTemp = first.path ?? (first.destination && first.filename ? path.join(first.destination, first.filename) : undefined);
        if (uploadedPathTemp) {
          (req as any).body = {
            ...(req as any).body,
            documentPath: uploadedPathTemp
          };
        }
      }
    }

    const parsed = InvokeSchema.parse(req.body as InvokeBody);

    console.log(`[${requestId}] Request validated successfully`);
    console.log(`Question: "${parsed.question}"`);
    console.log(`Prompt type: ${parsed.promptType || 'default'}`);

    // Determine document source: inline text > uploaded files > documentPath
    let document: string;
    const uploadedFiles = (req as any).files as any[] | undefined;

    if (parsed.documentText) {
      console.log(`[${requestId}] Using inline document text (${parsed.documentText.length} chars)`);
      document = parsed.documentText;
    } else if (uploadedFiles && uploadedFiles.length > 0) {
      // Process each uploaded file, ensure extension is present, load and concatenate
      const parts: string[] = [];
      for (const f of uploadedFiles) {
        let uploadedPath = f.path ?? (f.destination && f.filename ? path.join(f.destination, f.filename) : undefined);
        if (!uploadedPath) {
          console.warn(`[${requestId}] Skipping uploaded file with unavailable path: ${f.originalname}`);
          continue;
        }

        const originalExt = path.extname(f.originalname || "");
        let pathToLoad = uploadedPath;
        let renamed = false;
        if (originalExt && !uploadedPath.endsWith(originalExt)) {
          const newPath = `${uploadedPath}${originalExt}`;
          try {
            await fs.rename(uploadedPath, newPath);
            pathToLoad = newPath;
            renamed = true;
            console.log(`[${requestId}] Renamed uploaded temp file to include extension: ${newPath}`);
          } catch (e) {
            console.warn(`[${requestId}] Failed to rename uploaded temp file to include extension, continuing with original path: ${uploadedPath}`, e instanceof Error ? e.message : String(e));
          }
        }

        console.log(`[${requestId}] Document uploaded: ${f.originalname} -> ${pathToLoad}`);
        try {
          const txt = await loadDocumentToString(pathToLoad);
          parts.push(txt);
        } catch (e) {
          console.warn(`[${requestId}] Failed to load uploaded file ${pathToLoad}:`, e instanceof Error ? e.message : String(e));
        }

        // Cleanup: try to remove both the loaded path and original if renamed
        try {
          await fs.unlink(pathToLoad);
          console.log(`[${requestId}] Temporary uploaded file removed: ${pathToLoad}`);
        } catch (e) {
          if (renamed) {
            try {
              await fs.unlink(uploadedPath);
              console.log(`[${requestId}] Temporary uploaded file removed: ${uploadedPath}`);
            } catch (err) {
              console.warn(`[${requestId}] Failed to remove temp files: ${pathToLoad} and ${uploadedPath}`, err instanceof Error ? err.message : String(err));
            }
          } else {
            console.warn(`[${requestId}] Failed to remove temp file: ${pathToLoad}`, e instanceof Error ? e.message : String(e));
          }
        }
      }

      if (parts.length === 0) throw new Error("No uploaded files could be processed");
      // Join multiple documents with a clear separator so the chain sees them as distinct
      document = parts.join("\n\n---\n\n");
    } else if (parsed.documentPath) {
      console.log(`[${requestId}] Loading document from path: ${parsed.documentPath}`);
      document = await loadDocumentToString(parsed.documentPath as string);
    } else {
      throw new Error("No documentText, uploaded file, or documentPath provided in request");
    }

    console.log(`[${requestId}] Document loaded: ${document.length} characters`);

    // Guard against sending extremely large documents to the model which can
    // trigger token-limit errors like: "Please reduce the length of the messages or completion."
    // Use an environment-configurable limit; default to 15000 characters (~11k tokens conservatively).
    const MAX_DOC_CHARS = Number(process.env.MAX_DOC_CHARS ?? 15000);
    let documentTruncated = false;
    if (document.length > MAX_DOC_CHARS) {
      console.warn(`[${requestId}] Document exceeds ${MAX_DOC_CHARS} chars — truncating before model invocation.`);
      document = document.slice(0, MAX_DOC_CHARS);
      documentTruncated = true;
    }

    const modelInfo = getModelInfo();
    console.log(`[${requestId}] Using model: ${modelInfo.provider}/${modelInfo.model}`);

    const model = createChatModel();
    const chain = buildQAChain(model, parsed.promptType);

    console.log(`[${requestId}] Processing with QA chain...`);
    const startTime = Date.now();

    const output = await chain.invoke({
      document,
      question: parsed.question
    });

    const duration = Date.now() - startTime;
    console.log(`[${requestId}] Chain processing completed in ${duration}ms`);
    console.log(`[${requestId}] Output length: ${output.length} characters`);

    const result: InvokeResult = {
      output,
      model: modelInfo.model,
      provider: modelInfo.provider,
      promptType: parsed.promptType || "default"
    };

    console.log(`📤 [${requestId}] Sending response to client`);
    console.log(`====================================\n`);

    res.json(result);
  } catch (err: any) {
    console.error(`\n[${requestId}] === REQUEST ERROR ===`);
    console.error(`Error:`, err.message ?? String(err));
    console.error(`Stack:`, err.stack);
    console.error(`====================================\n`);

    res.status(400).json({ error: err.message ?? String(err) });
  }
});

const port = Number(process.env.PORT ?? 8787);
const host = process.env.HOST ?? "localhost";
const serverUrl = process.env.SERVER_URL ?? `http://${host}:${port}`;

app.listen(port, () => {
  const modelInfo = getModelInfo();
  console.log(`QA Bot API listening on ${serverUrl}`);
  console.log(`Provider: ${modelInfo.provider}`);
  console.log(`Model: ${modelInfo.model}`);
  console.log(`Temperature: ${modelInfo.temperature}`);
});
