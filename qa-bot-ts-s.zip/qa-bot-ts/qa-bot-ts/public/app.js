const form = document.getElementById('qa-form');
const filesEl = document.getElementById('files');
const questionEl = document.getElementById('question');
const promptTypeEl = document.getElementById('promptType');
const statusEl = document.getElementById('status');
const resultEl = document.getElementById('result');

function setStatus(msg, isError = false) {
  statusEl.textContent = msg;
  statusEl.style.color = isError ? 'crimson' : '#333';
}

function setResult(text) {
  resultEl.textContent = text;
}

form.addEventListener('submit', async (ev) => {
  ev.preventDefault();
  setStatus('Uploading files and asking question...');
  setResult('');

  const files = filesEl.files;
  const question = questionEl.value.trim();
  const promptType = promptTypeEl.value;

  if (!question) {
    setStatus('Please enter a question', true);
    return;
  }

  const fd = new FormData();
  fd.append('question', question);
  fd.append('promptType', promptType);
  for (let i = 0; i < files.length; i++) {
    fd.append('file', files[i], files[i].name);
  }

  try {
    const resp = await fetch('/search/document', {
      method: 'POST',
      body: fd
    });

    if (!resp.ok) {
      const text = await resp.text();
      setStatus(`Server error: ${resp.status} ${text}`, true);
      return;
    }

    const json = await resp.json();
    if (json.error) {
      setStatus(`Error: ${json.error}`, true);
      return;
    }

    setStatus('Response received');
    setResult(json.output || JSON.stringify(json, null, 2));
  } catch (err) {
    setStatus(err.message || String(err), true);
  }
});
