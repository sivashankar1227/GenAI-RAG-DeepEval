
Steps to implement

1. Extract the code and add folder to your workspace (existing)
2. npm install
3. update groq and mistral key in .env
4. npm run dev
5. Test the endpoints using postman.

## React Client UI (new)

A full Material-UI based React TypeScript application has been added under `client/` directory:

### Features:
- **Search Tab**: Keyword, vector, and hybrid search with real-time filtering
- **Chat Tab**: Conversational interface with memory and follow-up filtering
- **Metrics Tab**: DeepEval evaluation UI for testing model outputs against multiple quality metrics
- **Dark/Light Mode**: Enterprise theme toggle
- **Responsive Design**: Works on all devices

### Setup:
```bash
# Option 1: Quick setup script
./setup.bat          # Windows
./setup.sh           # macOS/Linux

# Option 2: Manual setup
npm install          # Backend dependencies
cd client && npm install  # Client dependencies
```

### Run in Development:
```bash
# Terminal 1: Backend API (root directory)
npm run dev

# Terminal 2: React client with hot reload (root directory)
cd client && npm start
# Opens http://localhost:3000 with proxy to backend
```

### Production Build:
```bash
# Build React client
cd client && npm run build

# Backend serves built client at http://localhost:8787
npm start
```

### Project Structure:
```
client/
├── src/
│   ├── components/
│   │   ├── SearchComponent.tsx    - Resume search UI
│   │   ├── ChatComponent.tsx      - Conversational chat
│   │   └── MetricsComponent.tsx   - DeepEval metrics evaluation
│   ├── App.tsx                    - Main app shell with tabs & theme
│   └── index.tsx                  - React entry point
├── public/index.html              - HTML entry point
├── package.json                   - React scripts (start, build)
└── tsconfig.json                  - TypeScript config
```

### API Integration:
All components use axios to call backend endpoints:
- `POST /search/resumes` - Search with keyword/vector/hybrid
- `POST /chat` - Conversational chat with memory
- `POST /eval` - DeepEval metrics evaluation
- `GET /health` - Server status check

## DeepEval Integration (previously added)

- Backend: Added `POST /eval` that proxies requests to the Deepeval sidecar (FastAPI) at `DEEPEVAL_SERVER_URL` (set in `.env`). This endpoint accepts the same payload as Deepeval: `{ query, context, output, expected_output, metric }` and returns a list of metric results.
- CLI Scripts:
  - `npm run evaluate` runs `src/scripts/evaluateOutput.ts` — it calls `/search/document` to generate an LLM output, then posts that output to `/eval` to get metrics for faithfulness, relevancy, hallucination, bias and toxicity.
  - `npm run evaluate:resumes` runs `src/scripts/evaluateResumes.ts` — it calls `/search/resumes` to retrieve context, calls `/chat` to generate an LLM answer, then calls `/eval` to compute metrics across several metrics.
- Front-end: Minimal `public/eval.html` UI added. Visit `http://localhost:8787/eval.html` (server static host) to run custom metric evaluations against the running Deepeval sidecar.

Usage notes:
- Ensure `DEEPEVAL_SERVER_URL` points to your running Deepeval server (default `http://localhost:8000`).
- Start QA bot server with `npm run dev`. Start Deepeval sidecar (Python) separately (see `deepeval-server` README) and ensure it is available on `DEEPEVAL_SERVER_URL`.
- Run `npm run evaluate` or `npm run evaluate:resumes` to test the end-to-end evaluation flow.

Steps to add 

1. Integrate deepeval to test the output of the endpoints.
   /test/resumes >>> search/resumes >>> test the input (query + docs) and output using deepeval. ✅
2. Start with one metric (answer relevance) and then add more metrics. ✅
3. Build a web app (use rag-mongo-demo) as reference so that HR can use ✅

Note: Use my mongo connection string for testing purpose.
