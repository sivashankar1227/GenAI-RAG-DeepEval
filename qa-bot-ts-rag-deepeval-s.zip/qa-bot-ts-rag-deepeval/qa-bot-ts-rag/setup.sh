#!/bin/bash
# Setup script for QA Bot full stack (backend + React client)

set -e

echo "🚀 Setting up QA Bot..."

# Setup backend
echo "📦 Setting up backend..."
npm install

# Setup client
echo "📦 Setting up React client..."
cd client
npm install
cd ..

echo "✅ Setup complete!"
echo ""
echo "📋 Next steps:"
echo ""
echo "1. Start the backend server (from root directory):"
echo "   npm run dev"
echo ""
echo "2. Start the React client (in a new terminal, from root directory):"
echo "   cd client && npm start"
echo ""
echo "3. Open your browser:"
echo "   http://localhost:3000 (development with hot reload)"
echo "   http://localhost:8787 (production build served by backend)"
echo ""
echo "4. Make sure DeepEval sidecar is running:"
echo "   python deepeval_server.py (from deepeval-demo directory)"
echo ""
