# QA Bot - React Client

This is the React TypeScript front-end for the QA Bot resume search and evaluation application, using Material-UI for styling and responsive design.

## Features

- **Resume Search**: Keyword, vector, and hybrid search with real-time results
- **Conversational Chat**: Multi-turn chat with conversation memory and filtering
- **Metrics Evaluation**: Evaluate LLM outputs using DeepEval metrics (faithfulness, relevancy, bias, toxicity, hallucination, etc.)
- **Material-UI Theme**: Enterprise-grade dark/light mode theme
- **Responsive Design**: Works on desktop, tablet, and mobile devices

## Setup

### Prerequisites

- Node.js >= 18.17
- npm or yarn

### Installation

```bash
cd client
npm install
```

### Development

To run the development server with hot reload:

```bash
npm start
```

The app will open at `http://localhost:3000` and proxy API requests to `http://localhost:8787` (the backend server).

### Build

To build the production bundle:

```bash
npm run build
```

Output goes to `client/build/` and is served by the backend at `http://localhost:8787` when running the full stack.

## Project Structure

```
client/
├── public/
│   └── index.html          # HTML entry point
├── src/
│   ├── components/
│   │   ├── SearchComponent.tsx      # Resume search UI
│   │   ├── ChatComponent.tsx        # Conversational chat UI
│   │   └── MetricsComponent.tsx     # DeepEval metrics evaluation UI
│   ├── App.tsx             # Main app with tabs and theme
│   ├── index.tsx           # React entry point
│   ├── index.css           # Global styles
│   └── ...
├── package.json
├── tsconfig.json
└── README.md
```

## Running the Full Stack

1. **Start the backend server** (from the parent directory):
   ```bash
   npm run dev
   ```

2. **Start the client** (from `client/` directory):
   ```bash
   npm start
   ```

   Or use the proxy by running both and navigating to `http://localhost:3000` during development.

3. **Build and serve together**:
   ```bash
   # From client/
   npm run build
   
   # Backend will serve client/build at http://localhost:8787
   ```

## Environment

- **Backend API Base URL**: Configured via proxy in `package.json` for development (`http://localhost:8787`)
- **Production**: The React build is served by the Express backend at the root path

## Styles

Uses Material-UI (MUI) v7 with:

- Emotion for CSS-in-JS
- Custom enterprise theme (deep blue + amber colors)
- Dark/light mode toggle in the AppBar
- Responsive typography and grid layouts

## DeepEval Integration

The Metrics tab evaluates model outputs using the backend `/eval` endpoint, which proxies requests to the DeepEval sidecar (default: `http://localhost:8000`).

Supported metrics:
- Faithfulness
- Answer Relevancy
- Contextual Precision / Recall
- Hallucination Detection
- Bias Detection
- Toxicity Detection

## Notes

- The client uses TypeScript for type safety
- Axios is used for HTTP requests to the backend
- Notistack provides snackbar notifications (can be added later)
- React 19 with modern JSX syntax
