import React, { useState, useEffect } from 'react';
import {
  CssBaseline,
  ThemeProvider,
  createTheme,
  Box,
  AppBar,
  Toolbar,
  Typography,
  Drawer,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  ListItemButton,
  Container,
  Tabs,
  Tab,
  useMediaQuery,
  IconButton,
  Tooltip,
} from '@mui/material';
import {
  Search as SearchIcon,
  Chat as ChatIcon,
  Dashboard as DashboardIcon,
  Menu as MenuIcon,
  ChevronLeft as ChevronLeftIcon,
  Brightness4 as DarkModeIcon,
  Brightness7 as LightModeIcon,
  Psychology as MetricsIcon,
} from '@mui/icons-material';
import { SnackbarProvider } from 'notistack';

// Import components
import SearchComponent from './components/SearchComponent';
import ChatComponent from './components/ChatComponent';
import MetricsComponent from './components/MetricsComponent';

const createEnterpriseTheme = (mode: 'light' | 'dark') =>
  createTheme({
    palette: {
      mode,
      primary: {
        main: '#0D47A1',
        light: '#5472D3',
        dark: '#002171',
        contrastText: '#ffffff',
      },
      secondary: {
        main: '#FF6F00',
        light: '#FF9F40',
        dark: '#C43E00',
        contrastText: '#000000',
      },
      background: {
        default: mode === 'light' ? '#F4F6F8' : '#121212',
        paper: mode === 'light' ? '#FFFFFF' : '#1E1E1E',
      },
      text: {
        primary: mode === 'light' ? '#1A1A1A' : '#FFFFFF',
        secondary: mode === 'light' ? '#6B7280' : '#B0B0B0',
      },
    },
    typography: {
      fontFamily: '"Roboto", "Helvetica", "Arial", sans-serif',
      h4: {
        fontWeight: 700,
        fontSize: '2rem',
        lineHeight: 1.2,
      },
      h6: {
        fontWeight: 600,
        fontSize: '1.125rem',
      },
    },
  });

interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}

function TabPanel(props: TabPanelProps) {
  const { children, value, index, ...other } = props;
  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      {...other}
    >
      {value === index && <Box sx={{ p: 3 }}>{children}</Box>}
    </div>
  );
}

function App() {
  const [tabValue, setTabValue] = useState(0);
  const [darkMode, setDarkMode] = useState(false);
  const [openDrawer, setOpenDrawer] = useState(true);
  const isMobile = useMediaQuery('(max-width:600px)');
  const theme = createEnterpriseTheme(darkMode ? 'dark' : 'light');

  useEffect(() => {
    if (isMobile) {
      setOpenDrawer(false);
    }
  }, [isMobile]);

  const handleTabChange = (_event: React.SyntheticEvent, newValue: number) => {
    setTabValue(newValue);
  };

  const menuItems = [
    { label: 'Search Resumes', icon: <SearchIcon />, index: 0 },
    { label: 'Chat', icon: <ChatIcon />, index: 1 },
    { label: 'Metrics Evaluation', icon: <MetricsIcon />, index: 2 },
  ];

  return (
    <ThemeProvider theme={theme}>
      <SnackbarProvider maxSnack={3}>
        <CssBaseline />
        <Box sx={{ display: 'flex', height: '100vh' }}>
          {/* AppBar */}
          <AppBar position="fixed" sx={{ zIndex: 1201 }}>
            <Toolbar>
              <IconButton
                color="inherit"
                onClick={() => setOpenDrawer(!openDrawer)}
                sx={{ mr: 2 }}
              >
                {openDrawer ? <ChevronLeftIcon /> : <MenuIcon />}
              </IconButton>
              <DashboardIcon sx={{ mr: 1 }} />
              <Typography variant="h6" sx={{ flexGrow: 1 }}>
                QA Bot - Resume Search & Evaluation
              </Typography>
              <Tooltip title="Toggle Theme">
                <IconButton
                  color="inherit"
                  onClick={() => setDarkMode(!darkMode)}
                >
                  {darkMode ? <LightModeIcon /> : <DarkModeIcon />}
                </IconButton>
              </Tooltip>
            </Toolbar>
          </AppBar>

          {/* Drawer */}
          <Drawer
            variant={isMobile ? 'temporary' : 'permanent'}
            open={openDrawer}
            onClose={() => setOpenDrawer(false)}
            sx={{
              width: 240,
              flexShrink: 0,
              '& .MuiDrawer-paper': {
                width: 240,
                boxSizing: 'border-box',
                marginTop: '64px',
                height: 'calc(100% - 64px)',
              },
            }}
          >
            <List>
              {menuItems.map((item) => (
                <ListItemButton
                  key={item.index}
                  selected={tabValue === item.index}
                  onClick={() => {
                    setTabValue(item.index);
                    if (isMobile) setOpenDrawer(false);
                  }}
                >
                  <ListItemIcon>{item.icon}</ListItemIcon>
                  <ListItemText primary={item.label} />
                </ListItemButton>
              ))}
            </List>
          </Drawer>

          {/* Main Content */}
          <Box
            sx={{
              flexGrow: 1,
              display: 'flex',
              flexDirection: 'column',
              overflow: 'hidden',
              marginTop: '64px',
            }}
          >
            {/* Tabs for desktop nav (optional) */}
            {!isMobile && (
              <Box sx={{ borderBottom: 1, borderColor: 'divider', bgcolor: 'background.paper' }}>
                <Tabs value={tabValue} onChange={handleTabChange}>
                  {menuItems.map((item) => (
                    <Tab
                      key={item.index}
                      label={item.label}
                      icon={item.icon}
                      iconPosition="start"
                    />
                  ))}
                </Tabs>
              </Box>
            )}

            {/* Tab Panels */}
            <Box sx={{ flexGrow: 1, overflowY: 'auto' }}>
              <TabPanel value={tabValue} index={0}>
                <SearchComponent />
              </TabPanel>
              <TabPanel value={tabValue} index={1}>
                <ChatComponent />
              </TabPanel>
              <TabPanel value={tabValue} index={2}>
                <MetricsComponent />
              </TabPanel>
            </Box>
          </Box>
        </Box>
      </SnackbarProvider>
    </ThemeProvider>
  );
}

export default App;
