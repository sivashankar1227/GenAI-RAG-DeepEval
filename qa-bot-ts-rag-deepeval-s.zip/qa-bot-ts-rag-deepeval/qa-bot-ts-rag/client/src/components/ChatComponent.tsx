import React, { useState, useRef, useEffect, ChangeEvent, KeyboardEvent } from 'react';
import {
  Box,
  Button,
  Card,
  CardContent,
  CircularProgress,
  TextField,
  Typography,
  Alert,
  Divider,
  Paper,
  FormControlLabel,
  Checkbox,
  Select,
  MenuItem,
} from '@mui/material';
import { Send as SendIcon, Delete as DeleteIcon, Close as CloseIcon } from '@mui/icons-material';
import axios from 'axios';

interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
  timestamp?: string;
}

interface SearchResult {
  fileName: string;
  email: string;
  phoneNumber: string;
  score: number;
  matchType?: string;
}

interface ChatResponse {
  response: string;
  conversationId: string;
  messageCount: number;
  model: string;
  provider: string;
  searchResults?: SearchResult[];
  searchMetadata?: {
    query: string;
    searchType: string;
    resultCount: number;
    duration: number;
  };
}

const ChatComponent: React.FC = () => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [conversationId, setConversationId] = useState<string>('');
  const [userInput, setUserInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [includeHistory, setIncludeHistory] = useState(true);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [lastSearchResults, setLastSearchResults] = useState<SearchResult[]>([]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = async () => {
    if (!userInput.trim()) return;

    const userMessage: ChatMessage = {
      role: 'user',
      content: userInput,
      timestamp: new Date().toLocaleTimeString(),
    };

    setMessages((prev: ChatMessage[]) => [...prev, userMessage]);
    setUserInput('');
    setLoading(true);
    setError(null);

    try {
      const payload: any = {
        message: userInput,
        includeHistory,
      };

      if (conversationId) {
        payload.conversationId = conversationId;
      }

      const response = await axios.post<ChatResponse>('/chat', payload);

      setConversationId(response.data.conversationId);
      setLastSearchResults(response.data.searchResults || []);

      const assistantMessage: ChatMessage = {
        role: 'assistant',
        content: response.data.response,
        timestamp: new Date().toLocaleTimeString(),
      };

      setMessages((prev: ChatMessage[]) => [...prev, assistantMessage]);
    } catch (err: any) {
      setError(err.response?.data?.error || err.message || 'Chat failed');
    } finally {
      setLoading(false);
    }
  };

  const handleNewConversation = () => {
    setMessages([]);
    setConversationId('');
    setUserInput('');
    setError(null);
    setLastSearchResults([]);
  };

  const handleCopyMessage = (content: string) => {
    navigator.clipboard.writeText(content);
  };

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      <Typography variant="h5" gutterBottom sx={{ mb: 2 }}>
        💬 Chat - Conversational Resume Search
      </Typography>

      {/* Conversation ID Display */}
      {conversationId && (
        <Alert severity="info" sx={{ mb: 2 }}>
          Conversation: {conversationId} · Messages: {messages.length}
        </Alert>
      )}

      {/* Controls */}
      <Box sx={{ display: 'flex', gap: 1, mb: 2, flexWrap: 'wrap' }}>
        <FormControlLabel
          control={<Checkbox checked={includeHistory} onChange={(e: ChangeEvent<HTMLInputElement>) => setIncludeHistory(e.target.checked)} />}
          label="Include History"
        />
        <Button
          variant="outlined"
          startIcon={<DeleteIcon />}
          onClick={handleNewConversation}
          size="small"
        >
          New Conversation
        </Button>
      </Box>

      {/* Chat Messages Area */}
      <Paper
        sx={{
          flexGrow: 1,
          overflowY: 'auto',
          mb: 2,
          p: 2,
          bgcolor: 'background.default',
          borderRadius: 1,
          display: 'flex',
          flexDirection: 'column',
        }}
      >
        {messages.length === 0 ? (
          <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100%' }}>
            <Typography variant="body2" color="textSecondary">
              Start a conversation by typing a message below...
            </Typography>
          </Box>
        ) : (
          <>
            {messages.map((msg: ChatMessage, idx: number) => (
              <Box
                key={idx}
                sx={{
                  display: 'flex',
                  justifyContent: msg.role === 'user' ? 'flex-end' : 'flex-start',
                  mb: 2,
                }}
              >
                <Card
                  sx={{
                    maxWidth: '70%',
                    bgcolor: msg.role === 'user' ? 'primary.main' : 'background.paper',
                    color: msg.role === 'user' ? 'primary.contrastText' : 'text.primary',
                  }}
                >
                  <CardContent sx={{ pb: 1 }}>
                    <Typography variant="body2">{msg.content}</Typography>
                    <Typography variant="caption" sx={{ opacity: 0.7, display: 'block', mt: 1 }}>
                      {msg.timestamp}
                    </Typography>
                    <Button
                      size="small"
                      sx={{ mt: 1, textTransform: 'none' }}
                      onClick={() => handleCopyMessage(msg.content)}
                    >
                      Copy
                    </Button>
                  </CardContent>
                </Card>
              </Box>
            ))}
            <div ref={messagesEndRef} />
          </>
        )}
      </Paper>

      {/* Error Display */}
      {error && (
        <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError(null)}>
          {error}
        </Alert>
      )}

      {/* Input Area */}
      <Box sx={{ display: 'flex', gap: 1 }}>
        <TextField
          fullWidth
          placeholder="Type your message..."
          value={userInput}
          onChange={(e: ChangeEvent<HTMLInputElement>) => setUserInput(e.target.value)}
          onKeyPress={(e: KeyboardEvent<HTMLInputElement>) => {
            if (e.key === 'Enter' && !loading) handleSendMessage();
          }}
          disabled={loading}
          multiline
          maxRows={3}
        />
        <Button
          variant="contained"
          endIcon={loading ? <CircularProgress size={20} /> : <SendIcon />}
          onClick={handleSendMessage}
          disabled={loading || !userInput.trim()}
          sx={{ mb: 0 }}
        >
          Send
        </Button>
      </Box>

      {/* Last Search Results */}
      {lastSearchResults.length > 0 && (
        <Box sx={{ mt: 2, p: 2, bgcolor: 'background.paper', borderRadius: 1 }}>
          <Typography variant="subtitle2" gutterBottom>
            📋 Search Results from Last Message
          </Typography>
          <Divider sx={{ mb: 1 }} />
          {lastSearchResults.slice(0, 3).map((result: SearchResult, idx: number) => (
            <Typography key={idx} variant="caption" display="block">
              • {result.fileName} ({(result.score * 100).toFixed(0)}%)
            </Typography>
          ))}
        </Box>
      )}
    </Box>
  );
};

export default ChatComponent;
