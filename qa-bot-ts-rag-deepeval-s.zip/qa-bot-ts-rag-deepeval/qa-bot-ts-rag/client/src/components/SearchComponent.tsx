import React, { useState, ChangeEvent, KeyboardEvent } from 'react';
import {
  Box,
  Button,
  Card,
  CardContent,
  CircularProgress,
  FormControlLabel,
  Radio,
  RadioGroup,
  TextField,
  Typography,
  Alert,
  List,
  ListItem,
  ListItemText,
  Divider,
  Grid,
} from '@mui/material';
import { Search as SearchIcon, Close as CloseIcon } from '@mui/icons-material';
import axios from 'axios';

interface SearchResult {
  fileName: string;
  email: string;
  phoneNumber: string;
  score: number;
  matchType?: string;
  content?: string;
}

interface SearchResponse {
  query: string;
  searchType: string;
  topK: number;
  resultCount: number;
  duration: number;
  results: SearchResult[];
  metadata?: any;
}

const SearchComponent: React.FC = () => {
  const [query, setQuery] = useState('');
  const [searchType, setSearchType] = useState<'keyword' | 'vector' | 'hybrid'>('hybrid');
  const [topK, setTopK] = useState(5);
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<SearchResult[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [searchTime, setSearchTime] = useState(0);

  const handleSearch = async () => {
    if (!query.trim()) {
      setError('Please enter a search query');
      return;
    }

    setLoading(true);
    setError(null);
    setResults([]);

    try {
      const response = await axios.post<SearchResponse>('/search/resumes', {
        query: query.trim(),
        searchType,
        topK,
      });

      setResults(response.data.results || []);
      setSearchTime(response.data.duration || 0);
    } catch (err: any) {
      setError(err.response?.data?.error || err.message || 'Search failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Box>
      <Typography variant="h5" gutterBottom sx={{ mb: 3 }}>
        🔍 Search Resumes
      </Typography>

      {/* Search Controls */}
      <Card sx={{ mb: 3 }}>
        <CardContent>
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
            <TextField
              fullWidth
              label="Search Query"
              value={query}
              onChange={(e: ChangeEvent<HTMLInputElement>) => setQuery(e.target.value)}
              placeholder="e.g., Senior TypeScript Developer"
              disabled={loading}
              onKeyPress={(e: KeyboardEvent<HTMLInputElement>) => {
                if (e.key === 'Enter') handleSearch();
              }}
            />

            <Box sx={{ display: 'flex', gap: 2, flexWrap: 'wrap' }}>
              <Box sx={{ flex: '1 1 calc(50% - 8px)', minWidth: 200 }}>
                <Typography variant="body2" sx={{ mb: 1 }}>
                  Search Type
                </Typography>
                <RadioGroup
                  value={searchType}
                  onChange={(e: ChangeEvent<HTMLInputElement>) => setSearchType(e.target.value as any)}
                  row
                >
                  <FormControlLabel value="keyword" control={<Radio />} label="Keyword" />
                  <FormControlLabel value="vector" control={<Radio />} label="Vector" />
                  <FormControlLabel value="hybrid" control={<Radio />} label="Hybrid" />
                </RadioGroup>
              </Box>

              <TextField
                sx={{ flex: '1 1 calc(50% - 8px)', minWidth: 200 }}
                type="number"
                label="Top K Results"
                value={topK}
                onChange={(e: ChangeEvent<HTMLInputElement>) => setTopK(Math.max(1, Math.min(100, parseInt(e.target.value) || 1)))}
                inputProps={{ min: 1, max: 100 }}
                disabled={loading}
              />
            </Box>

            <Button
              fullWidth
              variant="contained"
              startIcon={loading ? <CircularProgress size={20} /> : <SearchIcon />}
              onClick={handleSearch}
              disabled={loading}
              size="large"
            >
              {loading ? 'Searching...' : 'Search'}
            </Button>
          </Box>
        </CardContent>
      </Card>

      {/* Error Alert */}
      {error && (
        <Alert severity="error" sx={{ mb: 2 }}>
          {error}
        </Alert>
      )}

      {/* Results */}
      {results.length > 0 && (
        <Card>
          <CardContent>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
              <Typography variant="h6">
                Results ({results.length}) · Time: {searchTime}ms
              </Typography>
              <Button
                size="small"
                startIcon={<CloseIcon />}
                onClick={() => setResults([])}
              >
                Clear
              </Button>
            </Box>
            <Divider sx={{ mb: 2 }} />
            <List sx={{ maxHeight: 400, overflowY: 'auto' }}>
              {results.map((result: SearchResult, idx: number) => (
                <React.Fragment key={idx}>
                  <ListItem>
                    <ListItemText
                      primary={
                        <Typography variant="body1" sx={{ fontWeight: 600 }}>
                          {result.fileName}
                        </Typography>
                      }
                      secondary={
                        <Box>
                          <Typography variant="caption" display="block">
                            📧 {result.email} · 📞 {result.phoneNumber}
                          </Typography>
                          <Typography variant="caption" display="block">
                            Score: {(result.score * 100).toFixed(1)}% | Type: {result.matchType || 'unknown'}
                          </Typography>
                        </Box>
                      }
                    />
                  </ListItem>
                  {idx < results.length - 1 && <Divider />}
                </React.Fragment>
              ))}
            </List>
          </CardContent>
        </Card>
      )}

      {!loading && results.length === 0 && query && (
        <Alert severity="info">
          No results found. Try a different query or search type.
        </Alert>
      )}
    </Box>
  );
};

export default SearchComponent;
