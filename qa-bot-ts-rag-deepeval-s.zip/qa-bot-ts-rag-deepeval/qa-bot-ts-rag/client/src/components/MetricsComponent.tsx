import React, { useState, ChangeEvent } from 'react';
import {
  Box,
  Button,
  Card,
  CardContent,
  CircularProgress,
  TextField,
  Typography,
  Alert,
  Chip,
  LinearProgress,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  Divider,
  Paper,
} from '@mui/material';
import { Psychology as EvalIcon, Close as CloseIcon } from '@mui/icons-material';
import axios from 'axios';

interface MetricResult {
  metric_name: string;
  score?: number;
  explanation?: string;
  error?: string;
}

interface EvalResponse {
  results: MetricResult[];
  error?: string;
}

const MetricsComponent: React.FC = () => {
  const [query, setQuery] = useState('');
  const [context, setContext] = useState('');
  const [output, setOutput] = useState('');
  const [expectedOutput, setExpectedOutput] = useState('');
  const [metric, setMetric] = useState('all');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [results, setResults] = useState<MetricResult[]>([]);
  const [evalTime, setEvalTime] = useState(0);

  const availableMetrics = [
    { value: 'all', label: 'All Metrics' },
    { value: 'faithfulness', label: 'Faithfulness' },
    { value: 'answer_relevancy', label: 'Answer Relevancy' },
    { value: 'contextual_precision', label: 'Contextual Precision' },
    { value: 'contextual_recall', label: 'Contextual Recall' },
    { value: 'hallucination', label: 'Hallucination Detection' },
    { value: 'bias', label: 'Bias Detection' },
    { value: 'toxicity', label: 'Toxicity Detection' },
  ];

  const handleEvaluate = async () => {
    if (!output.trim()) {
      setError('Please enter model output');
      return;
    }

    setLoading(true);
    setError(null);
    setResults([]);

    const startTime = Date.now();

    try {
      const payload = {
        query: query.trim() || undefined,
        context: context.trim() ? context.split('\n').filter(Boolean) : undefined,
        output: output.trim(),
        expected_output: expectedOutput.trim() || undefined,
        metric: metric === 'all' ? 'all' : [metric],
      };

      const response = await axios.post<EvalResponse>('/eval', payload);

      setResults(response.data.results || []);
      setEvalTime(Date.now() - startTime);
    } catch (err: any) {
      setError(err.response?.data?.error || err.message || 'Evaluation failed');
    } finally {
      setLoading(false);
    }
  };

  const getScoreColor = (score?: number): 'success' | 'warning' | 'error' => {
    if (score === undefined) return 'warning';
    // Lower is better for most metrics (bias, toxicity, hallucination)
    // Higher is better for others (faithfulness, relevancy, precision, recall)
    if (score > 0.7) return 'success';
    if (score > 0.4) return 'warning';
    return 'error';
  };

  const getScoreLabel = (metric: string, score?: number): string => {
    if (score === undefined) return 'N/A';
    const percentage = (score * 100).toFixed(1);
    const isLowerBetter = ['bias', 'toxicity', 'hallucination'].includes(metric.toLowerCase());
    return isLowerBetter ? `${percentage}% (lower is better)` : `${percentage}%`;
  };

  return (
    <Box>
      <Typography variant="h5" gutterBottom sx={{ mb: 3 }}>
        📊 DeepEval Metrics Evaluation
      </Typography>

      {/* Evaluation Form */}
      <Card sx={{ mb: 3 }}>
        <CardContent>
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
            <TextField
              fullWidth
              label="Query (optional)"
              value={query}
              onChange={(e: ChangeEvent<HTMLInputElement>) => setQuery(e.target.value)}
              placeholder="e.g., What is the candidate's role?"
              disabled={loading}
              multiline
              rows={2}
            />

            <TextField
              fullWidth
              label="Context (optional, one per line)"
              value={context}
              onChange={(e: ChangeEvent<HTMLInputElement>) => setContext(e.target.value)}
              placeholder="Retrieved documents or source passages..."
              disabled={loading}
              multiline
              rows={3}
            />

            <TextField
              fullWidth
              label="Model Output (required)"
              value={output}
              onChange={(e: ChangeEvent<HTMLInputElement>) => setOutput(e.target.value)}
              placeholder="LLM generated response to evaluate"
              disabled={loading}
              multiline
              rows={4}
            />

            <TextField
              fullWidth
              label="Expected Output (optional)"
              value={expectedOutput}
              onChange={(e: ChangeEvent<HTMLInputElement>) => setExpectedOutput(e.target.value)}
              placeholder="Reference answer for contextual metrics"
              disabled={loading}
              multiline
              rows={2}
            />

            <Box sx={{ display: 'flex', gap: 2, flexWrap: 'wrap' }}>
              <FormControl sx={{ flex: '1 1 calc(50% - 8px)', minWidth: 200 }}>
                <InputLabel>Metrics to Evaluate</InputLabel>
                <Select
                  value={metric}
                  onChange={(e) => setMetric(e.target.value as string)}
                  label="Metrics to Evaluate"
                  disabled={loading}
                >
                  {availableMetrics.map((opt) => (
                    <MenuItem key={opt.value} value={opt.value}>
                      {opt.label}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Box>

            <Button
              fullWidth
              variant="contained"
              startIcon={loading ? <CircularProgress size={20} /> : <EvalIcon />}
              onClick={handleEvaluate}
              disabled={loading}
              size="large"
            >
              {loading ? 'Evaluating...' : 'Evaluate'}
            </Button>
          </Box>
        </CardContent>
      </Card>

      {/* Error Alert */}
      {error && (
        <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError(null)}>
          {error}
        </Alert>
      )}

      {/* Results */}
      {results.length > 0 && (
        <Card>
          <CardContent>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
              <Typography variant="h6">
                Evaluation Results · Time: {evalTime}ms
              </Typography>
              <Button
                size="small"
                startIcon={<CloseIcon />}
                onClick={() => setResults([])}
              >
                Clear
              </Button>
            </Box>
            <Divider sx={{ mb: 2 }} />

            <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr', md: 'repeat(3, 1fr)' }, gap: 2 }}>
              {results.map((result: MetricResult, idx: number) => (
                <Paper
                  key={idx}
                  sx={{
                    p: 2,
                    border: '1px solid',
                    borderColor: 'divider',
                    borderRadius: 1,
                    height: '100%',
                    display: 'flex',
                    flexDirection: 'column',
                  }}
                >
                  <Typography variant="subtitle2" sx={{ fontWeight: 600, mb: 1 }}>
                    {result.metric_name.replace(/_/g, ' ').toUpperCase()}
                  </Typography>

                  {result.error ? (
                    <Alert severity="warning" sx={{ mb: 1 }}>
                      {result.error}
                    </Alert>
                  ) : result.score !== undefined ? (
                    <>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1 }}>
                        <Chip
                          label={getScoreLabel(result.metric_name, result.score)}
                          color={getScoreColor(result.score)}
                          size="small"
                        />
                      </Box>
                      <LinearProgress
                        variant="determinate"
                        value={Math.min(100, (result.score || 0) * 100)}
                        sx={{ mb: 1 }}
                      />
                    </>
                  ) : null}

                  {result.explanation && (
                    <Typography variant="caption" sx={{ flexGrow: 1, mt: 1 }}>
                      {result.explanation}
                    </Typography>
                  )}
                </Paper>
              ))}
            </Box>
          </CardContent>
        </Card>
      )}

      {!loading && results.length === 0 && !error && (
        <Alert severity="info">
          Fill in the form above and click "Evaluate" to run metrics on your model output.
        </Alert>
      )}
    </Box>
  );
};

export default MetricsComponent;
