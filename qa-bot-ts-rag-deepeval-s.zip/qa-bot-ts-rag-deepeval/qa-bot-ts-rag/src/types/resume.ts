export interface ResumeData {
  email: string;
  phoneNumber: string;
  fullContent: string;
  fileName: string;
  processedAt: Date;
  embedding?: number[]; // Vector embedding for semantic search
  // Metadata extracted by LLM
  name?: string;
  locations?: string[];
  skills?: string[];
  technologies?: string[];
  currentOrganisation?: string;
  currentTitle?: string;
  yearsOfExperience?: number;
  totalExperience?: string;
  educationLevel?: string;
  certifications?: string[];
  languages?: string[];
  previousOrganisations?: string[];
  previousTitles?: string[];
}

export interface ExtractionResult {
  email: string | null;
  phoneNumber: string | null;
  fullContent: string;
}

export interface LLMExtractedMetadata {
  name?: string;
  locations?: string[];
  skills?: string[];
  technologies?: string[];
  currentOrganisation?: string;
  currentTitle?: string;
  yearsOfExperience?: number;
  totalExperience?: string;
  educationLevel?: string;
  certifications?: string[];
  languages?: string[];
  previousOrganisations?: string[];
  previousTitles?: string[];
}

export interface EmbeddingConfig {
  provider: string;
  model: string;
  apiKey: string;
}
