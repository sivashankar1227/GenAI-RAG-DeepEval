import { BaseChatModel } from "@langchain/core/language_models/chat_models";
import { ChatGroq } from "@langchain/groq";

/**
 * Create a chat model using Groq provider
 * Provider: Groq (required)
 * Model: Specified via GROQ_MODEL env var
 */
export function createChatModel(): BaseChatModel {
  const temperature = Number(process.env.TEMPERATURE ?? 0.1);

  // Validate temperature
  if (isNaN(temperature) || temperature < 0 || temperature > 2) {
    throw new Error(`Invalid temperature: ${process.env.TEMPERATURE}. Must be between 0 and 2.`);
  }

  const apiKey = process.env.GROQ_API_KEY;
  const model = process.env.GROQ_MODEL;

  if (!apiKey) {
    throw new Error("GROQ_API_KEY is required");
  }

  if (!model) {
    throw new Error("GROQ_MODEL is required");
  }

  return new ChatGroq({
    apiKey,
    model,
    temperature,
  }) as unknown as BaseChatModel;
}

/**
 * Get information about the current model configuration
 */
export function getModelInfo(): {
  provider: string;
  model: string;
  temperature: number;
} {
  const temperature = Number(process.env.TEMPERATURE ?? 0.1);
  const model = process.env.GROQ_MODEL ?? "unknown";

  return { provider: "groq", model, temperature };
}
