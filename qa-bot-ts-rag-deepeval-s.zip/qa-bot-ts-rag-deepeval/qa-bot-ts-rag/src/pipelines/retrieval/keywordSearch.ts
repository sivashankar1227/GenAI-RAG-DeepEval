import { Collection } from "mongodb";
import { SearchResultItem, SearchMetadata } from "./types.js";

/**
 * Keyword-based search on resume content and metadata
 */
export class KeywordSearchEngine {
  private collection: Collection;

  constructor(collection: Collection) {
    this.collection = collection;
  }

  /**
   * Perform keyword search using regex matching
   */
  async search(query: string, topK: number, metadata: SearchMetadata): Promise<SearchResultItem[]> {
    console.log(`[${metadata.traceId}] [Keyword Search] Query: "${query}", TopK: ${topK}`);
    const startTime = Date.now();

    try {
      // Split query into keywords and create regex pattern
      const keywords = query.trim().split(/\s+/);
      const searchRegex = new RegExp(keywords.join("|"), "i");

      // Find documents matching the keyword in content, filename, email, or metadata fields
      const cursor = this.collection
        .find({
          $or: [
            { fullContent: { $regex: searchRegex } },
            { fileName: { $regex: searchRegex } },
            { email: { $regex: searchRegex } },
            { name: { $regex: searchRegex } },
            { currentTitle: { $regex: searchRegex } },
            { currentOrganisation: { $regex: searchRegex } },
            { skills: { $regex: searchRegex } },
            { locations: { $regex: searchRegex } },
            { technologies: { $regex: searchRegex } },
            { certifications: { $regex: searchRegex } },
            { languages: { $regex: searchRegex } },
            { previousOrganisations: { $regex: searchRegex } },
            { previousTitles: { $regex: searchRegex } },
          ],
        })
        .limit(topK * 2); // Get more for better scoring

      const documents = await cursor.toArray();
      const duration = Date.now() - startTime;

      console.log(`[${metadata.traceId}] [Keyword Search] Found ${documents.length} candidates in ${duration}ms`);

      // Calculate relevance score based on keyword frequency and position
      const results: SearchResultItem[] = documents.map((doc) => {
        const content = doc.fullContent || "";
        const fileName = doc.fileName || "";
        const email = doc.email || "";
        const name = doc.name || "";
        const title = doc.currentTitle || "";
        const org = doc.currentOrganisation || "";
        const skillsText = (doc.skills || []).join(" ");
        const locationsText = (doc.locations || []).join(" ");
        const techText = (doc.technologies || []).join(" ");
        
        // Count matches in each field with different weights
        const contentMatches = (content.match(searchRegex) || []).length;
        const fileNameMatches = (fileName.match(searchRegex) || []).length;
        const emailMatches = (email.match(searchRegex) || []).length;
        const nameMatches = (name.match(searchRegex) || []).length;
        const titleMatches = (title.match(searchRegex) || []).length;
        const orgMatches = (org.match(searchRegex) || []).length;
        const skillsMatches = (skillsText.match(searchRegex) || []).length;
        const locationsMatches = (locationsText.match(searchRegex) || []).length;
        const techMatches = (techText.match(searchRegex) || []).length;
        
        // Weight different fields (metadata gets higher weight)
        const totalScore = 
          (contentMatches * 1.0) + 
          (fileNameMatches * 2.0) + 
          (emailMatches * 1.5) +
          (nameMatches * 2.5) +
          (titleMatches * 3.0) +      // High priority: job title
          (orgMatches * 2.5) +         // High priority: organization
          (skillsMatches * 3.5) +      // Very high priority: skills
          (locationsMatches * 2.0) +   // High priority: locations
          (techMatches * 3.0);         // Very high priority: technologies
        
        // Normalize to 0-1 range (assuming max 30 matches is highly relevant)
        const normalizedScore = Math.min(totalScore / 30, 1.0);

        return {
          fileName: fileName || "Unknown",
          email: email || "Not found",
          phoneNumber: doc.phoneNumber || "Not found",
          content: this.extractSnippet(content, keywords),
          score: normalizedScore,
          matchType: "keyword",
          // Include metadata fields
          name: doc.name,
          currentTitle: doc.currentTitle,
          currentOrganisation: doc.currentOrganisation,
          skills: doc.skills,
          locations: doc.locations,
          technologies: doc.technologies,
          yearsOfExperience: doc.yearsOfExperience,
          totalExperience: doc.totalExperience,
          educationLevel: doc.educationLevel,
          certifications: doc.certifications,
          languages: doc.languages,
          previousOrganisations: doc.previousOrganisations,
          previousTitles: doc.previousTitles,
        };
      });

      // Sort by score and return topK
      const topResults = results
        .sort((a, b) => b.score - a.score)
        .slice(0, topK);

      console.log(`[${metadata.traceId}] [Keyword Search] Returning ${topResults.length} results`);
      return topResults;
      
    } catch (error) {
      console.error(`[${metadata.traceId}] [Keyword Search] Error:`, error);
      throw new Error(`Keyword search failed: ${error instanceof Error ? error.message : String(error)}`);
    }
  }

  /**
   * Extract relevant snippet around matched keywords
   */
  private extractSnippet(content: string, keywords: string[], maxLength: number = 200): string {
    if (!content) return "";
    
    // Find first keyword match
    const lowerContent = content.toLowerCase();
    const lowerKeywords = keywords.map(k => k.toLowerCase());
    
    let position = -1;
    for (const keyword of lowerKeywords) {
      position = lowerContent.indexOf(keyword);
      if (position !== -1) break;
    }
    
    if (position === -1) {
      // No match found, return beginning
      return content.substring(0, maxLength) + "...";
    }
    
    // Extract snippet around the match
    const start = Math.max(0, position - 50);
    const end = Math.min(content.length, position + maxLength - 50);
    
    let snippet = content.substring(start, end);
    if (start > 0) snippet = "..." + snippet;
    if (end < content.length) snippet = snippet + "...";
    
    return snippet.trim();
  }
}
