export { ingestResumes } from "./pipeline.js";
