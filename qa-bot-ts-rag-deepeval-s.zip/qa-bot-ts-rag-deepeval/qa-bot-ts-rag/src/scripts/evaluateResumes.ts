import "dotenv/config";
import fetch from "node-fetch";

const serverUrl = process.env.SERVER_URL || "http://localhost:8787";

async function main() {
  const query = process.argv[2] || "senior software engineer with TypeScript";
  const topK = parseInt(process.argv[3] || "3", 10);

  console.log(`Searching for: ${query}`);

  const searchResp = await fetch(`${serverUrl}/search/resumes`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ query, searchType: "hybrid", topK }),
  });

  if (!searchResp.ok) {
    console.error("Search failed:", await searchResp.text());
    process.exit(1);
  }

  const searchJson = await searchResp.json();
  console.log("Search results received", searchJson.resultCount);

  const context = (searchJson.results || []).map((r: any) => r.content).slice(0, topK);

  // Use /chat to generate an answer based on the conversation using the query
  console.log("Generating an LLM answer via /chat...");

  const chatResp = await fetch(`${serverUrl}/chat`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ message: query }),
  });

  if (!chatResp.ok) {
    console.error("Chat call failed:", await chatResp.text());
    process.exit(1);
  }

  const chatJson = await chatResp.json();
  const answer = chatJson.response || "";

  console.log("LLM answer:", answer);

  // Call /eval to evaluate the LLM's answer
  const evalPayload = {
    query,
    context,
    output: answer,
    expected_output: "Senior software engineer experienced with TypeScript and Node.js",
    metric: ["faithfulness", "answer_relevancy", "contextual_precision", "contextual_recall", "hallucination", "bias", "toxicity"]
  };

  console.log("Sending to /eval:", JSON.stringify(evalPayload, null, 2));

  const evalResp = await fetch(`${serverUrl}/eval`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(evalPayload),
  });

  if (!evalResp.ok) {
    console.error("Evaluation failed:", await evalResp.text());
    process.exit(1);
  }

  const evalJson = await evalResp.json();
  console.log("Evaluation Results:\n", JSON.stringify(evalJson, null, 2));
}

main().catch(err => {
  console.error("Script error:", err);
});
