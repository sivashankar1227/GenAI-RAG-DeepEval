import "dotenv/config";
import fetch from "node-fetch";

const serverUrl = process.env.SERVER_URL || "http://localhost:8787";

async function main() {
  const question = process.argv[2] || "What is the role of the resume candidate?";
  const documentText = process.argv[3] || "John Doe is a senior software engineer with experience in TypeScript, Node.js, and MongoDB.";

  console.log("Preparing to call /search/document to generate model output...\n");

  // Call the QA endpoint
  const invokeResponse = await fetch(`${serverUrl}/search/document`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ question, documentText }),
  });

  if (!invokeResponse.ok) {
    console.error("Failed to call /search/document:", await invokeResponse.text());
    process.exit(1);
  }

  const invokeJson = await invokeResponse.json();
  console.log("Invoke output:", invokeJson);

  const evalPayload = {
    query: question,
    context: [documentText],
    output: invokeJson.output || "",
    expected_output: "Senior software engineer with TypeScript, Node.js and MongoDB.",
    metric: ["faithfulness", "answer_relevancy", "hallucination", "bias", "toxicity"]
  };

  console.log("Sending payload to /eval...\n", JSON.stringify(evalPayload, null, 2));

  const evalResp = await fetch(`${serverUrl}/eval`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(evalPayload),
  });

  if (!evalResp.ok) {
    console.error("Evaluation failed:", await evalResp.text());
    process.exit(1);
  }

  const evalJson = await evalResp.json();
  console.log("Evaluation results:\n", JSON.stringify(evalJson, null, 2));
}

main().catch(err => {
  console.error("Script error:", err);
});
