/**
 * Helper script to get a valid JWT token for testleaf API
 * Run this first to get a token, then update the .env file
 */

import axios from 'axios';
import dotenv from 'dotenv';

dotenv.config();

const TESTLEAF_API_BASE = process.env.TESTLEAF_API_BASE || 'http://localhost:8080/ai';
const USER_EMAIL = process.env.USER_EMAIL || 'babu@testleaf.com';

async function getAuthToken() {
    try {
        console.log('🔐 Getting authentication token...');
        console.log(`📧 Email: ${USER_EMAIL}`);
        
        // You'll need to provide the password here
        const password = process.env.USER_PASSWORD || 'your-password-here'; // Replace with actual password
        
        const loginResponse = await axios.post(
            `${TESTLEAF_API_BASE}/auth/login`,
            {
                email: USER_EMAIL,
                password: password
            },
            {
                headers: {
                    'Content-Type': 'application/json'
                }
            }
        );

        if (loginResponse.data.status === 200) {
            const token = loginResponse.data.token;
            console.log('✅ Authentication successful!');
            console.log('🎫 JWT Token:', token);
            console.log('\n📝 Update your .env file with:');
            console.log(`AUTH_TOKEN="${token}"`);
            
            // Test the token immediately
            console.log('\n🧪 Testing the token with embedding API...');
            const testResponse = await axios.post(
                `${TESTLEAF_API_BASE}/embedding/text/${USER_EMAIL}`,
                {
                    input: "test input for authentication",
                    model: "text-embedding-3-small"
                },
                {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${token}`
                    }
                }
            );
            
            if (testResponse.data.status === 200) {
                console.log('✅ Token works! Embedding test successful.');
                console.log('💰 Test cost:', testResponse.data.cost);
                console.log('🔢 Test tokens:', testResponse.data.usage?.total_tokens);
            } else {
                console.log('❌ Token test failed:', testResponse.data.message);
            }
            
        } else {
            console.log('❌ Login failed:', loginResponse.data.message);
        }

    } catch (error) {
        if (error.response) {
            console.error('❌ API Error:', error.response.status, error.response.data);
        } else {
            console.error('❌ Error:', error.message);
        }
        
        console.log('\n💡 Tips:');
        console.log('1. Make sure the testleaf backend server is running on port 8080');
        console.log('2. Update the password in this script');
        console.log('3. Make sure the user email exists in the database');
        console.log('4. Check if the user has proper permissions');
    }
}

// Run the script
getAuthToken();