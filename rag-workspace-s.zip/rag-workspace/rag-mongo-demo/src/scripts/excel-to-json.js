import xlsx from "xlsx";
import fs from "fs";

// ✅ CONFIGURATION
const excelFile = "src/data/Healthcare_App_500_Testcases_Metadata.xlsx";      
const sheetName = "Testcases";   
const outputFile = "src/data/testcases_500_Metadata.json";      

// Map Excel column headers → JSON keys
const columnMap = {
  "Module": "module",
  "Test ID": "id",
  "Pre-Requisites": "preRequisites",
  "Test Title": "title",
  "Test Case Description": "description",
  "Test Steps": "steps",
  "Expected Results": "expectedResults",
  "Automation/Manual": "automationManual",
  "Priority": "priority",
  "Created By": "createdBy",
  "Created Date": "createdDate",
  "Last modified date": "lastModifiedDate",
  "Risk": "risk",
  "Version": "version",
  "Type": "type"
};

// ✅ LOAD EXCEL FILE
const workbook = xlsx.readFile(excelFile);
const worksheet = workbook.Sheets[sheetName];

if (!worksheet) {
  console.error(`❌ Sheet "${sheetName}" not found in ${excelFile}`);
  process.exit(1);
}

// Convert sheet to JSON
const rawData = xlsx.utils.sheet_to_json(worksheet, { defval: "" });

// ✅ TRANSFORM USING columnMap
const jsonData = rawData.map((row, index) => {
  const mappedRow = {};
  for (const [excelCol, jsonKey] of Object.entries(columnMap)) {
    mappedRow[jsonKey] = row[excelCol] || "";
  }
  return mappedRow;
});

// ✅ WRITE TO FILE
fs.writeFileSync(outputFile, JSON.stringify(jsonData, null, 2), "utf-8");

console.log(`✅ Converted ${jsonData.length} rows from "${sheetName}" into ${outputFile}`);
