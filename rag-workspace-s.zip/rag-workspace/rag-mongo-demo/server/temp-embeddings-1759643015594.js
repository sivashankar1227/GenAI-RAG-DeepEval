
import { MongoClient } from "mongodb";
import dns from "dns";
import axios from "axios";
import dotenv from "dotenv";
import fs from "fs";

dotenv.config();

dns.setServers(['8.8.8.8', '8.8.4.4']);

const client = new MongoClient(process.env.MONGODB_URI, {
  ssl: true,
  tlsAllowInvalidCertificates: true,
  tlsAllowInvalidHostnames: true,
  serverSelectionTimeoutMS: 30000,
  connectTimeoutMS: 30000,
  socketTimeoutMS: 30000,
});

const TESTLEAF_API_BASE = process.env.TESTLEAF_API_BASE || 'https://api.testleaf.ai';
const USER_EMAIL = process.env.USER_EMAIL;
const AUTH_TOKEN = process.env.AUTH_TOKEN;

async function main() {
  try {
    await client.connect();
    const db = client.db(process.env.DB_NAME);
    const collection = db.collection(process.env.COLLECTION_NAME);

    const testcases = JSON.parse(fs.readFileSync("D:/Gen AI Learning/Week2Day2/rag-workspace/rag-mongo-demo/src/data/testcases_500_Metadata.json", "utf-8"));

    console.log(`🚀 Processing ${testcases.length} test cases from testcases_500_Metadata.json...`);
    
    let totalCost = 0;
    let totalTokens = 0;
    let processed = 0;

    for (const testcase of testcases) {
      try {
        const inputText = `
          Module: ${testcase.module}
          ID: ${testcase.id}
          Pre-Requisites: ${testcase.preRequisites}
          Title: ${testcase.title}
          Description: ${testcase.description}
          Steps: ${testcase.steps}
          Expected Result: ${testcase.expectedResults}
          Automation/Manual: ${testcase.automationManual}
          Priority: ${testcase.priority}
          Created By: ${testcase.createdBy}
          Created Date: ${testcase.createdDate}
          Last Modified Date: ${testcase.lastModifiedDate}
          Risk: ${testcase.risk}
          Version: ${testcase.version}
          Type: ${testcase.type}
        `;
        
        const embeddingResponse = await axios.post(
          `${TESTLEAF_API_BASE}/embedding/text/${USER_EMAIL}`,
          {
            input: inputText,
            model: "text-embedding-3-small"
          },
          {
            headers: {
              'Content-Type': 'application/json',
              ...(AUTH_TOKEN && { 'Authorization': `Bearer ${AUTH_TOKEN}` })
            }
          }
        );

        if (embeddingResponse.data.status !== 200) {
          throw new Error(`Testleaf API error: ${embeddingResponse.data.message}`);
        }

        const vector = embeddingResponse.data.data[0].embedding;
        const cost = embeddingResponse.data.cost || 0;
        const tokens = embeddingResponse.data.usage?.total_tokens || 0;
        
        totalCost += cost;
        totalTokens += tokens;

        const doc = {
          ...testcase,
          embedding: vector,
          createdAt: new Date(),
          sourceFile: "testcases_500_Metadata.json",
          embeddingMetadata: {
            model: embeddingResponse.data.model,
            cost: cost,
            tokens: tokens,
            apiSource: 'testleaf'
          }
        };

        await collection.insertOne(doc);
        processed++;
        
        console.log(`✅ Processed ${processed}/${testcases.length}: ${testcase.id}`);
        
        await new Promise(resolve => setTimeout(resolve, 100));
        
      } catch (error) {
        console.error(`❌ Error processing ${testcase.id}: ${error.message}`);
        continue;
      }
    }

    console.log(`\n🎉 Processing complete for testcases_500_Metadata.json!`);
    console.log(`💰 Total Cost: $${totalCost.toFixed(6)}`);
    console.log(`🔢 Total Tokens: ${totalTokens}`);
    console.log(`📊 Processed: ${processed}/${testcases.length}`);

  } catch (err) {
    console.error("❌ Error:", err.message);
    process.exit(1);
  } finally {
    await client.close();
  }
}

main();
