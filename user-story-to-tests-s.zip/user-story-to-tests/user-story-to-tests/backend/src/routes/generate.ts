import express from 'express'
import { GroqClient } from '../llm/groqClient'
import { GenerateRequestSchema, GenerateResponseSchema, GenerateResponse } from '../schemas'
import { SYSTEM_PROMPT, buildPrompt } from '../prompt'
import { fetchJiraIssue } from '../jiraClient'

export const generateRouter = express.Router()

generateRouter.post('/', async (req: express.Request, res: express.Response): Promise<void> => {
  try {
    // Validate request body
    const validationResult = GenerateRequestSchema.safeParse(req.body)
    
    if (!validationResult.success) {
      res.status(400).json({
        error: `Validation error: ${validationResult.error.message}`
      })
      return
    }

    const request = validationResult.data

    // Normalize categories if provided; treat empty as all (we'll pass empty to indicate All)
    const rawCategories = (req.body && req.body.categories) || []
    const normalizedCategories = Array.isArray(rawCategories)
      ? rawCategories.filter((c: string) => typeof c === 'string')
      : []

    // Attach normalized categories to the request passed to prompt builder
    const requestForPrompt: any = { ...request, categories: normalizedCategories }

    // If jiraId provided, fetch jira details (non-fatal)
    let jiraSummary: string | undefined = undefined
    let jiraDescription: string | undefined = undefined
    if (request.jiraId) {
      try {
        const issue = await fetchJiraIssue(request.jiraId)
        jiraSummary = issue.summary
        jiraDescription = issue.description
        requestForPrompt.jiraSummary = jiraSummary
        requestForPrompt.jiraDescription = jiraDescription
        requestForPrompt.jiraId = request.jiraId
      } catch (err) {
        console.warn('Failed to fetch JIRA issue server-side:', err)
      }
    }

    // Build prompts
    const userPrompt = buildPrompt(requestForPrompt)

    // Create GroqClient instance here to ensure env vars are loaded
    const groqClient = new GroqClient()

    // Generate tests using Groq
    try {
      const groqResponse = await groqClient.generateTests(SYSTEM_PROMPT, userPrompt)
      
      // Parse the JSON content
      let parsedResponse: GenerateResponse
      try {
        parsedResponse = JSON.parse(groqResponse.content)
      } catch (parseError) {
        res.status(502).json({
          error: 'LLM returned invalid JSON format'
        })
        return
      }

      // Validate the response schema
      const responseValidation = GenerateResponseSchema.safeParse(parsedResponse)
      if (!responseValidation.success) {
        res.status(502).json({
          error: 'LLM response does not match expected schema'
        })
        return
      }

      // Add token usage info if available
      const finalResponse = {
        ...responseValidation.data,
        model: groqResponse.model,
        promptTokens: groqResponse.promptTokens,
        completionTokens: groqResponse.completionTokens,
        chosenCategories: normalizedCategories, // echo back what was requested (empty => All)
        chosenJiraId: request.jiraId,
        jiraSummary,
        jiraDescription
      }

      res.json(finalResponse)
    } catch (llmError) {
      console.error('LLM error:', llmError)
      res.status(502).json({
        error: 'Failed to generate tests from LLM service'
      })
      return
    }
  } catch (error) {
    console.error('Error in generate route:', error)
    res.status(500).json({
      error: 'Internal server error'
    })
  }
})