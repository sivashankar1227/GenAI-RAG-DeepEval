import express from 'express'
import { z } from 'zod'
import { fetchJiraIssue } from '../jiraClient'
import { GroqClient } from '../llm/groqClient'
import { buildTestDataPrompt } from '../prompt'

const TestDataRequestSchema = z.object({
  jiraId: z.string().optional(),
  sampleCount: z.number().int().min(1).max(100).optional()
})

export const testDataRouter = express.Router()

testDataRouter.post('/', async (req: express.Request, res: express.Response) => {
  try {
    const parsed = TestDataRequestSchema.safeParse(req.body)
    if (!parsed.success) {
      return res.status(400).json({ error: 'Invalid request', details: parsed.error.flatten() })
    }

    const { jiraId, sampleCount = 5 } = parsed.data

    let jiraSummary: string | undefined
    let jiraDescription: string | undefined
    if (jiraId) {
      try {
        const issue = await fetchJiraIssue(jiraId)
        jiraSummary = issue.summary
        jiraDescription = issue.description
      } catch (err) {
        // Continue; we'll still try to generate test data without Jira context
        console.warn('Failed to fetch JIRA for testdata:', err)
      }
    }

    const prompt = buildTestDataPrompt({ jiraId, jiraSummary, jiraDescription, sampleCount })

    const client = new GroqClient()
    try {
      const groqResponse = await client.generateTests(prompt, '')
      // Try to parse content
      let parsedResponse: any
      try {
        parsedResponse = JSON.parse(groqResponse.content)
      } catch (e) {
        // Fallback: simple deterministic mock
        const mockRecords = Array.from({ length: sampleCount }).map((_, i) => ({ id: i + 1, name: `User ${i + 1}`, email: `user${i + 1}@example.com` }))
        return res.json({ records: mockRecords, pattern: [{ name: 'id', type: 'Number' }, { name: 'name', type: 'Full Name' }, { name: 'email', type: 'Email' }] })
      }

      // Basic validation
      if (!parsedResponse || !Array.isArray(parsedResponse.records)) {
        return res.status(502).json({ error: 'LLM did not return expected data format' })
      }

      return res.json(parsedResponse)
    } catch (llmErr) {
      console.error('LLM error generating test data:', llmErr)
      const mockRecords = Array.from({ length: sampleCount }).map((_, i) => ({ id: i + 1, name: `User ${i + 1}`, email: `user${i + 1}@example.com` }))
      return res.json({ records: mockRecords, pattern: [{ name: 'id', type: 'Number' }, { name: 'name', type: 'Full Name' }, { name: 'email', type: 'Email' }] })
    }
  } catch (err) {
    console.error('testdata route error:', err)
    res.status(500).json({ error: err instanceof Error ? err.message : 'Internal error' })
  }
})
