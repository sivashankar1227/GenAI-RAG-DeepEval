import express from 'express'
import { fetchJiraIssue } from '../jiraClient'

export const jiraRouter = express.Router()

jiraRouter.get('/:id', async (req, res) => {
  try {
    const id = String(req.params.id)
    const issue = await fetchJiraIssue(id)

    let acceptanceCriteria = ''
    if (issue.description) {
      const match = /Acceptance Criteria[:\s]*([\s\S]+)/i.exec(issue.description)
      acceptanceCriteria = match ? match[1].trim() : ''
    }

    res.json({
      storyTitle: issue.summary,
      description: issue.description,
      acceptanceCriteria
    })
  } catch (err) {
    console.error('JIRA route error:', err)
    res.status(502).json({ error: err instanceof Error ? err.message : 'Unknown error' })
  }
})
